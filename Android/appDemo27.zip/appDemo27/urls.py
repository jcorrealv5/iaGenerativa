from django.urls import path
from . import views
urlpatterns = [
    path('CambioBarba', views.CambioBarba, name='CambioBarba'),
    path('CambiarBarba', views.CambiarBarba, name='CambiarBarba')
]