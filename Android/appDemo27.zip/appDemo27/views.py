from django.http import HttpResponse
from django.shortcuts import render
from django.views.decorators.clickjacking import xframe_options_exempt
import torch, torchvision, cv2
import torchvision.transforms as T
import albumentations
from albumentations.pytorch import ToTensorV2
import numpy as np
import os
from io import BytesIO
from PIL import Image
from modGAN import LoadData, Generador

def CambioBarba(request):
    return render(request, "appDemo27/CambioBarba.html")

@xframe_options_exempt
def CambiarBarba(request):
    rpta = None
    barba = request.POST.get("barba")
    print("barba: ", barba)
    fileOrigen = request.FILES["blob"]
    fileOrigen.open()
    bytes = fileOrigen.read()
    fileOrigen.close()
    imagenBarbaActual = convertirBytesToNumPy(bytes)
    nCanales = imagenBarbaActual.shape[2]
    if(nCanales==4):
        imagenBarbaActual = imagenBarbaActual[:,:,:3]
    batch_size = 1
    transforms = albumentations.Compose(
    [albumentations.Resize(width=256, height=256),
        albumentations.Normalize(mean=[0.5, 0.5, 0.5],
        std=[0.5, 0.5, 0.5],max_pixel_value=255),
        ToTensorV2()],
    additional_targets={"image0": "image"})
    archivoSinBarba = "C:/Data/Python/2026_01_IAG/Demos/datasets/TestBigote/No/Jose_Sanchez.jpeg"
    archivoConBarba = "C:/Data/Python/2026_01_IAG/Demos/datasets/TestBigote/Si/Mayimbu.jpeg"
    device = "cuda" if torch.cuda.is_available() else "cpu"
    gen = Generador(img_channels=3, num_residuals=9).to(device)
    if(barba=="0"):
        imagenBarbaOpuesto = cv2.imread(archivoConBarba)        
        gen.load_state_dict(torch.load("C:/Data/Python/2026_01_IAG/Demos/preentrenados/GAN/Bigote/gen_conbigote_100.pth",map_location=device))
    else:
        imagenBarbaOpuesto = cv2.imread(archivoSinBarba)
        gen.load_state_dict(torch.load("C:/Data/Python/2026_01_IAG/Demos/preentrenados/GAN/Bigote/gen_sinbigote_100.pth",map_location=device))
    device = "cuda" if torch.cuda.is_available() else "cpu"

    imagenBarbaOpuesto = cv2.resize(imagenBarbaOpuesto, (256,256))
    imagenBarbaActual = cv2.resize(imagenBarbaActual, (256,256))
    if(barba=="0"):
        augmentations = transforms(image=imagenBarbaActual, image0=imagenBarbaOpuesto)
    else:
        augmentations = transforms(image=imagenBarbaOpuesto, image0=imagenBarbaActual)
    imgConBarba = augmentations["image0"]
    imgSinBarba = augmentations["image"]
    dstBarba = [(imgSinBarba, imgConBarba)]
    loaderBarba=torch.utils.data.DataLoader(dstBarba,batch_size=batch_size, shuffle=True, pin_memory=True, drop_last=True)
    for sinBarba,conBarba in loaderBarba:
        if(barba=="0"):
            fakeBarba=gen(sinBarba.to(device)).squeeze(0)
        else:
            fakeBarba=gen(conBarba.to(device)).squeeze(0)
    imgRpta = fakeBarba/2+0.5
    imgRpta = (imgRpta.clamp(0, 1) * 255).byte()
    imgRpta = imgRpta.permute(1,2,0).cpu().numpy()
    print("shape imgRpta: ", imgRpta.shape)
    imagen = convertirNumPyToBytes(imgRpta)
    return HttpResponse(imagen)

def convertirNumPyToBytes(imagen):
    imagenPIL = Image.fromarray(imagen)
    imagenBuffer = BytesIO()
    imagenPIL.save(imagenBuffer, format="PNG")
    rpta = imagenBuffer.getvalue()
    return rpta

def convertirBytesToNumPy(buffer):
    imagenPIL = Image.open(BytesIO(buffer))
    imagen = np.array(imagenPIL)
    return imagen