var nFiles = 0;
var cFiles = 0;
var archivos = [];
var nombres = [];

window.onload = function () {
	var listaBarba = ["|Seleccione", "0|Sin Barba", "1|Con Barba"];
	crearCombo(listaBarba, cboBarba);

	divCaras.ondragover = function (event) {
		event.preventDefault();
	}

	divCaras.ondrop = function (event) {
		event.preventDefault();
		var files = event.dataTransfer.items;
		if (files) {
			var nImagenes = divCaras.childNodes.length;
			var nArrastre = files.length;			
			var file;
			var c = 0;
			for (var i = 0; i < nArrastre; i++) {
				file = event.dataTransfer.items[i].getAsFile();
				nombre = file.name;
				if (nombres.indexOf(nombre)==-1) {
					archivos.push(file);
					nombres.push(nombre);
					c++;
				}
				else alert("Archivo: " + file.name + " ya fue agregado");
			}
			nFiles = nImagenes + c;
			leerImagen();
		}
	}
	
	btnCambiarBarba.onclick = async function () {
		if (cboBarba.value != "") {
			cFiles = 0;
			divProgreso.style.display = "inline";
			pbrCaras.min = 0;
			pbrCaras.value = 0;
			pbrCaras.max = nFiles;
			enviarImagen();
		}
		else alert("Selecciona la Barba");
	}

	btnNuevo.onclick = function () {
		archivos = [];
		nombres = [];
		cFiles = 0;
		cboBarba.value = "";		
		divCaras.innerHTML = "";
		divProgreso.style.display = "none";
    }
}

function leerImagen() {
	var file = archivos[cFiles];
	var reader = new FileReader();
	reader.onloadend = function () {
		var img = new Image(256, 256);
		img.id = file.name;
		img.src = reader.result;
		divCaras.appendChild(img);
		cFiles++;
		if (cFiles < nFiles) leerImagen();
	}
	reader.readAsDataURL(file);
}

async function enviarImagen() {
	var barba = cboBarba.value;
	var blob = archivos[cFiles];
	var token = document.getElementsByName("csrfmiddlewaretoken")[0].value;
	var frm = new FormData();
	frm.append("csrfmiddlewaretoken", token);
	frm.append("barba", barba);
	frm.append("blob", blob);
	var rptaHttp = await fetch("CambiarBarba", { method: "POST", body: frm });
	if (rptaHttp.ok) {
		var blob = await rptaHttp.blob();
		var nTotal = blob.size;
		if (nTotal > 0) {
			var blobImagen = new Blob([blob], { "type": "image/jpg" });
			var imgBarbaCambiada = document.getElementById(nombres[cFiles]);
			if (imgBarbaCambiada != null) imgBarbaCambiada.src = URL.createObjectURL(blobImagen);
			cFiles++;
			spnProgreso.innerText = cFiles + " de " + nFiles;
			pbrCaras.value = cFiles;
			if (cFiles % 5 == 0) divCaras.scrollTop = (250 * (cFiles / 5));
			if (cFiles < nFiles) enviarImagen();
			else alert("Se cambio: " + nFiles + " Barbas")
		}
	}
}

function crearCombo(lista, cbo, primerItem) {
	var primerItem = (primerItem == null ? "" : primerItem);
	var html = "";
	var nRegistros = lista.length;
	var campos = [];
	if (primerItem != "") {
		html += "<option value=''>";
		html += primerItem;
		html += "</option>";
	}
	for (var i = 0; i < nRegistros; i++) {
		campos = lista[i].split("|");
		html += "<option value='";
		html += campos[0];
		html += "'>";
		html += campos[1];
		html += "</option>";
	}
	cbo.innerHTML = html;
}