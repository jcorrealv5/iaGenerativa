package iag.appdemo07;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Arrays;
import iag.Interfaces.CallbackAsync;
import iag.Modulos.ClienteBytesHttp;
import iag.Modulos.Imagen;

public class MainActivity extends AppCompatActivity {
    Spinner cboCaraInicio;
    Spinner cboCaraFin;
    EditText txtNumero;
    ImageView imgCara;
    TextView lblProgreso;
    ArrayList<byte[]> listaImagenes;
    int c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cboCaraInicio = findViewById(R.id.cboCaraInicio);
        cboCaraFin = findViewById(R.id.cboCaraFin);
        txtNumero = findViewById(R.id.txtNumero);
        imgCara = findViewById(R.id.imgCara);
        lblProgreso = findViewById(R.id.lblProgreso);
        llenarCombosNombres();

        Button btnGenerar = findViewById(R.id.btnGenerar);
        btnGenerar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                servicioGenerarCaras();
            }
        });
    }

    private void llenarCombosNombres()
    {
        ArrayList<String> listaNombres=new ArrayList<>();
        listaNombres.add("Carlos");
        listaNombres.add("Edelson");
        listaNombres.add("Juan Carlos");
        listaNombres.add("Luis");
        listaNombres.add("Pedro");
        ArrayAdapter<String> adaptador=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,listaNombres);
        cboCaraInicio.setAdapter(adaptador);
        cboCaraFin.setAdapter(adaptador);
    }

    private void servicioGenerarCaras(){
        String caraInicio = String.valueOf(cboCaraInicio.getSelectedItemPosition());
        String caraFin = String.valueOf(cboCaraFin.getSelectedItemPosition());
        String numero = txtNumero.getText().toString();
        int nroVeces = Integer.parseInt(numero);
        c=0;
        String urlServicio = getResources().getString(R.string.urlServicioWeb);
        String urlMetodo = urlServicio + "GenerarCaras?caraInicio=" + caraInicio;
        urlMetodo += "&caraFin=" + caraFin + "&nMuestras=" + numero;
        ClienteBytesHttp.get(urlMetodo, new CallbackAsync() {
            @Override
            public void MostrarRespuestaBytesAsync(byte[] rpta) {
                if(rpta!=null && rpta.length>0){
                    int n1 = rpta[0] & 0xFF;
                    int n2 = rpta[1] & 0xFF;
                    int nTexto = n1 * 255 + n2;
                    byte[] rptaTexto = Arrays.copyOfRange(rpta, 2, 2 + nTexto);
                    String strSizes = new String(rptaTexto);
                    String[] listaSizes = strSizes.split("\\|");
                    listaImagenes = new ArrayList<byte[]>();
                    int x = 2 + nTexto;
                    byte[] buffer;
                    int size;
                    for(int i=0;i<listaSizes.length;i++){
                        size = Integer.parseInt(listaSizes[i]);
                        buffer = Arrays.copyOfRange(rpta, x, x + size);
                        listaImagenes.add(buffer);
                        x += size;
                    }
                    imgCara.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            mostrarImagen();
                            c++;
                            lblProgreso.setText(String.valueOf(c) + " de " + String.valueOf(nroVeces));
                            if(c<nroVeces){
                                imgCara.postDelayed(this, 250);
                            }
                        }
                    }, 250);
                }
            }
        });
    }

    private void mostrarImagen(){
        Imagen.mostrarDesdeBytes(listaImagenes.get(c), imgCara);
    }
}