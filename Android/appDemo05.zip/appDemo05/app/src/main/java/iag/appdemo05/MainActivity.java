package iag.appdemo05;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import java.net.URL;
import java.net.URLEncoder;
import iag.Interfaces.CallbackAsync;
import iag.Modulos.ClienteBytesHttp;
import iag.Modulos.Imagen;

public class MainActivity extends AppCompatActivity {
    TextView lblMensaje;
    ImageView imgGenerada;
    Button btnGenerar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lblMensaje = findViewById(R.id.lblMensaje);
        imgGenerada =findViewById(R.id.imgGenerada);

        btnGenerar = findViewById(R.id.btnGenerar);
        btnGenerar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnGenerar.setEnabled(false);
                servicioGenerarImagen();
            }
        });

        Button btnNuevo = findViewById(R.id.btnNuevo);
        btnNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lblMensaje.setText("");
                imgGenerada.setImageDrawable(null);
            }
        });
    }

    protected void servicioGenerarImagen(){
        EditText txtPrompt = findViewById(R.id.txtPrompt);
        String prompt = txtPrompt.getText().toString();
        EditText txtPromptNegativo = findViewById(R.id.txtPromptNegativo);
        String promptNegativo = txtPromptNegativo.getText().toString();
        String urlServicio = getResources().getString(R.string.urlServicioWeb);
        String urlMetodo = urlServicio + "GenerarImagen";
        String parametros = "";
        try{
            parametros = "prompt=" + URLEncoder.encode(prompt,"UTF-8") + "&promptNegativo=" + URLEncoder.encode(promptNegativo,"UTF-8");
            byte[] buffer = parametros.getBytes();
            ClienteBytesHttp.post(urlMetodo, new CallbackAsync() {
                @Override
                public void MostrarRespuestaBytesAsync(byte[] rpta) {
                    btnGenerar.setEnabled(true);
                    if(rpta!=null && rpta.length>0){
                        Imagen.mostrarDesdeBytes(rpta, imgGenerada);
                    }
                }
            }, buffer);
        }
        catch (Exception ex)
        {
            lblMensaje.setText(ex.getMessage());
        }
    }
}