package iag.Entidades;

public class beImagen {
    public byte[] Imagen;
}
