package iag.appdemo04;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import iag.Adaptadores.AdaptadorImagen;
import iag.Entidades.beImagen;
import iag.Interfaces.CallbackAsync;
import iag.Modulos.ClienteBytesHttp;
import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    int nMuestras;
    int cCaras;
    ArrayList<beImagen> lbeImagen;
    TextView lblMensaje;
    EditText txtNumero;
    ListView lvwCara;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lblMensaje = findViewById(R.id.lblMensaje);
        txtNumero = findViewById(R.id.txtNumero);
        lvwCara = findViewById(R.id.lvwCara);

        Button btnGenerarGAN = findViewById(R.id.btnGenerarGAN);
        btnGenerarGAN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nMuestras = Integer.parseInt(txtNumero.getText().toString());
                cCaras=0;
                lbeImagen = new ArrayList<beImagen>();
                servicioGenerarCara("GAN");
            }
        });

        Button btnGenerarDM = findViewById(R.id.btnGenerarDM);
        btnGenerarDM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nMuestras = Integer.parseInt(txtNumero.getText().toString());
                cCaras=0;
                lbeImagen = new ArrayList<beImagen>();
                servicioGenerarCara("DM");
            }
        });

        Button btnNuevo = findViewById(R.id.btnNuevo);
        btnNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtNumero.setText("10");
                lblMensaje.setText("");
                lbeImagen = new ArrayList<beImagen>();
                AdaptadorImagen adaptador=new AdaptadorImagen(getApplicationContext(), lbeImagen);
                lvwCara.setAdapter(adaptador);
            }
        });
    }

    private void servicioGenerarCara(String tipo){
        String urlServicio ="";
        String urlMetodo = "";
        if(tipo.equals("GAN")) {
            urlServicio = getResources().getString(R.string.urlServicioWebGAN);
            urlMetodo = urlServicio + "GenerarRostro";
        }
        else {
            urlServicio = getResources().getString(R.string.urlServicioWebDM);
            urlMetodo = urlServicio + "GenerarCara";
        }
        ClienteBytesHttp.get(urlMetodo, new CallbackAsync() {
            @Override
            public void MostrarRespuestaBytesAsync(byte[] rpta) {
                if(rpta!=null && rpta.length>0){
                    beImagen obeImagen =new beImagen();
                    obeImagen.Imagen = rpta;
                    lbeImagen.add(obeImagen);
                    AdaptadorImagen adaptador=new AdaptadorImagen(getApplicationContext(), lbeImagen);
                    lvwCara.setAdapter(adaptador);
                    cCaras++;
                    lblMensaje.setText(String.valueOf(cCaras) + " de " + String.valueOf(nMuestras));
                    if(cCaras<nMuestras) servicioGenerarCara(tipo);
                }
            }
        });
    }
}