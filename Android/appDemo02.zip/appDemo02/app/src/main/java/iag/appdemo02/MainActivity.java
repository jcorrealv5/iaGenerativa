package iag.appdemo02;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import iag.Adaptadores.AdaptadorImagen;
import iag.Entidades.beImagen;
import iag.Interfaces.CallbackAsync;
import iag.Modulos.ClienteBytesHttp;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnGenerar = findViewById(R.id.btnGenerar);
        btnGenerar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText txtNumero = findViewById(R.id.txtNumero);
                String nMuestras = txtNumero.getText().toString();
                obtenerRopaServicio(nMuestras);
            }
        });
    }

    private void obtenerRopaServicio(String nMuestras){
        String urlServicio = getResources().getString(R.string.urlServicioWeb);
        String urlMetodo = urlServicio + "GenerarRopa?nMuestras=" + nMuestras;
        ClienteBytesHttp.get(urlMetodo, new CallbackAsync() {
            @Override
            public void MostrarRespuestaBytesAsync(byte[] rpta) {
                if(rpta!=null && rpta.length>0){
                    int n1 = rpta[0] & 0xFF;
                    int n2 = rpta[1] & 0xFF;
                    int nTexto = n1 * 255 + n2;
                    byte[] rptaTexto = Arrays.copyOfRange(rpta, 2, 2 + nTexto);
                    String strSizes = new String(rptaTexto);
                    String[] listaSizes = strSizes.split("\\|");
                    ArrayList<beImagen> lbeImagen = new ArrayList<beImagen>();
                    int x = 2 + nTexto;
                    beImagen obeImagen;
                    int size;
                    for(int i=0;i<listaSizes.length;i++){
                        size = Integer.parseInt(listaSizes[i]);
                        obeImagen=new beImagen();
                        obeImagen.Imagen = Arrays.copyOfRange(rpta, x, x + size);
                        lbeImagen.add(obeImagen);
                        x += size;
                    }
                    ListView lvwRopa = findViewById(R.id.lvwRopa);
                    AdaptadorImagen adaptador=new AdaptadorImagen(getApplicationContext(), lbeImagen);
                    lvwRopa.setAdapter(adaptador);
                }
            }
        });
    }
}