package aig.Interfaces;
public interface CallbackAsync {
    void MostrarRespuestaBytesAsync(byte[] rpta);
}