package iag.Adaptadores;
import android.content.Context;
import android.view.LayoutInflater;
import android.widget.ArrayAdapter;

import java.util.ArrayList;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import iag.Entidades.beImagen;
import iag.Modulos.Imagen;
import iag.appdemo06.R;

public class AdaptadorImagen extends ArrayAdapter {
    public AdaptadorImagen(Context context, ArrayList<beImagen> data) {
        super(context, 0, data);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        beImagen obeImagen = (beImagen)getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.cara, parent, false);
        }
        if(obeImagen!=null){
            ImageView imgCara1 = convertView.findViewById(R.id.imgCara1);
            Imagen.mostrarDesdeBytes(obeImagen.Imagen1, imgCara1);
            ImageView imgCara2 = convertView.findViewById(R.id.imgCara2);
            Imagen.mostrarDesdeBytes(obeImagen.Imagen2, imgCara2);
            ImageView imgCara3 = convertView.findViewById(R.id.imgCara3);
            Imagen.mostrarDesdeBytes(obeImagen.Imagen3, imgCara3);
        }
        return convertView;
    }
}
