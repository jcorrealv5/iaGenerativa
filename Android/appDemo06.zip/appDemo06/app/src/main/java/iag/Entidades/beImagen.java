package iag.Entidades;

public class beImagen {
    public byte[] Imagen1;
    public byte[] Imagen2;
    public byte[] Imagen3;
}
