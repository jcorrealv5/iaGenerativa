package iag.appdemo06;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import iag.Adaptadores.AdaptadorImagen;
import iag.Entidades.beImagen;
import iag.Interfaces.CallbackAsync;
import iag.Modulos.ClienteBytesHttp;
import java.util.ArrayList;
import java.util.Arrays;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {
    TextView lblMensaje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lblMensaje = findViewById(R.id.lblMensaje);

        Button btnGenerar = findViewById(R.id.btnGenerar);
        btnGenerar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText txtFilas = findViewById(R.id.txtFilas);
                String filas = txtFilas.getText().toString();
                servicioGenerarCaras(filas);
            }
        });
    }

    private void servicioGenerarCaras(String filas) {
        String cols = "3";
        String parametros = "";
        String urlServicio = getResources().getString(R.string.urlServicioWeb);
        String urlMetodo = urlServicio + "GenerarCaras";
        try {
            parametros = "filas=" + URLEncoder.encode(filas, "UTF-8") + "&cols=" + URLEncoder.encode(cols, "UTF-8");
            byte[] buffer = parametros.getBytes();
            ClienteBytesHttp.post(urlMetodo, new CallbackAsync() {
                @Override
                public void MostrarRespuestaBytesAsync(byte[] rpta) {
                    if (rpta != null && rpta.length > 0) {
                        int n1 = rpta[0] & 0xFF;
                        int n2 = rpta[1] & 0xFF;
                        int nTexto = n1 * 255 + n2;
                        byte[] rptaTexto = Arrays.copyOfRange(rpta, 2, 2 + nTexto);
                        String strSizes = new String(rptaTexto);
                        String[] listaSizes = strSizes.split("\\|");
                        ArrayList<beImagen> lbeImagen = new ArrayList<beImagen>();
                        int x = 2 + nTexto;
                        beImagen obeImagen;
                        int size1, size2, size3;
                        for (int i = 0; i < listaSizes.length; i+=3) {
                            size1 = Integer.parseInt(listaSizes[i]);
                            size2 = Integer.parseInt(listaSizes[i+1]);
                            size3 = Integer.parseInt(listaSizes[i+2]);
                            obeImagen = new beImagen();
                            obeImagen.Imagen1 = Arrays.copyOfRange(rpta, x, x + size1);
                            x += size1;
                            obeImagen.Imagen2 = Arrays.copyOfRange(rpta, x, x + size2);
                            x += size2;
                            obeImagen.Imagen3 = Arrays.copyOfRange(rpta, x, x + size3);
                            x += size3;
                            lbeImagen.add(obeImagen);
                        }
                        ListView lvwCara = findViewById(R.id.lvwCara);
                        AdaptadorImagen adaptador = new AdaptadorImagen(getApplicationContext(), lbeImagen);
                        lvwCara.setAdapter(adaptador);
                    }
                }
            }, buffer);
        } catch (Exception ex) {
            lblMensaje.setText(ex.getMessage());
        }
    }
}