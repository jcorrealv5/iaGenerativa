package iag.appdemo10;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import iag.Interfaces.CallbackAsync;
import iag.Modulos.ClienteBytesHttp;
import iag.Modulos.Imagen;

public class MainActivity extends AppCompatActivity {
    ImageView imgPeloOriginal;
    ImageView imgPeloCambiado;
    Spinner cboPelo;
    TextView lblMensaje;
    byte[] buffer;

    private final ActivityResultLauncher<PickVisualMediaRequest> pickMedia =
            registerForActivityResult(new ActivityResultContracts.PickVisualMedia(), uri -> {
                if (uri != null) {
                    try {
                        buffer = Imagen.getBytesFromUri(getApplicationContext(), uri);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    imgPeloOriginal.setImageURI(uri);
                } else {
                    // Usuario canceló la selección
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cboPelo = findViewById(R.id.cboPelo);
        lblMensaje = findViewById(R.id.lblMensaje);
        imgPeloOriginal = findViewById(R.id.imgPeloOriginal);
        imgPeloCambiado = findViewById(R.id.imgPeloCambiado);
        llenarComboPelo();

        Button btnSeleccionarFoto = findViewById(R.id.btnSeleccionarFoto);
        btnSeleccionarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pickMedia.launch(new PickVisualMediaRequest.Builder()
                        .setMediaType(PickVisualMedia.ImageOnly.INSTANCE)
                        .build());
            }
        });

        Button btnCambiarPelo = findViewById(R.id.btnCambiarPelo);
        btnCambiarPelo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                servicioCambiarPelo();
            }
        });
    }

    protected void llenarComboPelo(){
        ArrayList<String> listaNombres=new ArrayList<>();
        listaNombres.add("Rubio");
        listaNombres.add("Negro");
        ArrayAdapter<String> adaptador=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,listaNombres);
        cboPelo.setAdapter(adaptador);
    }

    private void servicioCambiarPelo(){
        String color = String.valueOf(cboPelo.getSelectedItemPosition());
        try{
            String urlServicio = getResources().getString(R.string.urlServicioWeb);
            String urlMetodo = urlServicio + "CambiarPelo?color=" + color;
            ClienteBytesHttp.post(urlMetodo, new CallbackAsync() {
                @Override
                public void MostrarRespuestaBytesAsync(byte[] rpta) {
                        if(rpta!=null && rpta.length>0){
                            Imagen.mostrarDesdeBytes(rpta, imgPeloCambiado);
                        }
                    }
                }, buffer);
            }
        catch (Exception ex)
        {
            lblMensaje.setText(ex.getMessage());
        }
    }
}