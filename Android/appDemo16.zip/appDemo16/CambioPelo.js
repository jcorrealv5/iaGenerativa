window.onload = function () {
	var listaColores = ["|Seleccione", "0|Rubio", "1|Negro"];
	crearCombo(listaColores, cboColorPelo);

	btnAbrir.onclick = function () {
		fupFoto.click();
	}

	fupFoto.onchange = function (event) {
		var file = this.files[0];
		var reader = new FileReader();
		reader.onloadend = function (event) {
			imgPeloOriginal.src = reader.result;
        }
		reader.readAsDataURL(file);
    }
	
	btnCambiarPelo.onclick = async function () {
		if (cboColorPelo.value != "") {
			if (fupFoto.value != "") {
				var color = cboColorPelo.value;
				var file = fupFoto.files[0];
				var token = document.getElementsByName("csrfmiddlewaretoken")[0].value;
				var frm = new FormData();
				frm.append("csrfmiddlewaretoken", token);

				frm.append("archivo", file);				
				var rptaHttp = await fetch("CambiarPeloFile?color="+color, { method: "POST", body: frm });
				if (rptaHttp.ok) {
					var blob = await rptaHttp.blob();
					var nTotal = blob.size;
					if (nTotal > 0) {
						var blobImagen = new Blob([blob], { "type": "image/jpg" });
						imgPeloCambiado.src = URL.createObjectURL(blobImagen);
					}
				}
			}
			else alert("Selecciona una imagen a cambiar el Pelo");
		}
		else alert("Selecciona el Color de Pelo");
	}

	btnNuevo.onclick = function () {
		cboColorPelo.value = "";
		imgPeloOriginal.src = "";
		imgPeloCambiado.src = "";
    }
}

function crearCombo(lista, cbo, primerItem) {
	var primerItem = (primerItem == null ? "" : primerItem);
	var html = "";
	var nRegistros = lista.length;
	var campos = [];
	if (primerItem != "") {
		html += "<option value=''>";
		html += primerItem;
		html += "</option>";
	}
	for (var i = 0; i < nRegistros; i++) {
		campos = lista[i].split("|");
		html += "<option value='";
		html += campos[0];
		html += "'>";
		html += campos[1];
		html += "</option>";
	}
	cbo.innerHTML = html;
}