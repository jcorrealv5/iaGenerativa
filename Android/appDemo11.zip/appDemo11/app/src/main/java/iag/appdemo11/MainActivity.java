package iag.appdemo11;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import iag.Interfaces.CallbackAsync;
import iag.Modulos.ClienteBytesHttp;
import iag.Modulos.Imagen;

public class MainActivity extends AppCompatActivity {
    ImageView imgPeloOriginal;
    ImageView imgPeloCambiado;
    Spinner cboPelo;
    TextView lblMensaje;
    byte[] buffer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cboPelo = findViewById(R.id.cboPelo);
        lblMensaje = findViewById(R.id.lblMensaje);
        imgPeloOriginal = findViewById(R.id.imgPeloOriginal);
        imgPeloCambiado = findViewById(R.id.imgPeloCambiado);
        llenarComboPelo();

        Button btnTomarFoto = findViewById(R.id.btnTomarFoto);
        btnTomarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                try {
                    startActivityForResult(takePictureIntent, 1);
                } catch (ActivityNotFoundException e) {
                    lblMensaje.setText("Ocurrio un Error al activar la Camara");
                }

            }
        });

        Button btnCambiarPelo = findViewById(R.id.btnCambiarPelo);
        btnCambiarPelo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                servicioCambiarPelo();
            }
        });

        Button btnNuevo=findViewById(R.id.btnNuevo);
        btnNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lblMensaje.setText("");
                imgPeloOriginal.setImageDrawable(null);
                imgPeloCambiado.setImageDrawable(null);
            }
        });
    }

    protected void llenarComboPelo(){
        ArrayList<String> listaNombres=new ArrayList<>();
        listaNombres.add("Rubio");
        listaNombres.add("Negro");
        ArrayAdapter<String> adaptador=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,listaNombres);
        cboPelo.setAdapter(adaptador);
    }

    private void servicioCambiarPelo(){
        String color = String.valueOf(cboPelo.getSelectedItemPosition());
        try{
            String urlServicio = getResources().getString(R.string.urlServicioWeb);
            String urlMetodo = urlServicio + "CambiarPelo?color=" + color;
            ClienteBytesHttp.post(urlMetodo, new CallbackAsync() {
                @Override
                public void MostrarRespuestaBytesAsync(byte[] rpta) {
                    if(rpta!=null && rpta.length>0){
                        Imagen.mostrarDesdeBytes(rpta, imgPeloCambiado);
                    }
                }
            }, buffer);
        }
        catch (Exception ex)
        {
            lblMensaje.setText(ex.getMessage());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            try{
                Bundle extras = data.getExtras();
                if(extras!=null){
                    Bitmap bmp = (Bitmap) extras.get("data");
                    if(bmp!=null){
                        imgPeloOriginal.setImageBitmap(bmp);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
                        buffer = stream.toByteArray();
                    }
                }
            }
            catch (Exception ex){
                lblMensaje.setText(ex.getMessage());
            }
        }
    }
}