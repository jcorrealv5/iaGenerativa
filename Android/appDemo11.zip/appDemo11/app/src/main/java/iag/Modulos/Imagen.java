package iag.Modulos;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import android.widget.ImageView;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
public class Imagen {
    public static void mostrarDesdeBase64(String base64, ImageView iv)
    {
        byte[] decodedString = Base64.decode(base64, Base64.DEFAULT);
        Bitmap bmp = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        iv.setImageBitmap(bmp);
    }

    public static void mostrarDesdeBytes(byte[] buffer, ImageView iv)
    {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        InputStream is = new ByteArrayInputStream(buffer);
        Bitmap bmp = BitmapFactory.decodeStream(is);
        iv.setImageBitmap(bmp);
    }

    public static byte[] getBytesFromUri(Context context, Uri uri) throws IOException {
        InputStream inputStream = context.getContentResolver().openInputStream(uri);
        if (inputStream == null) {
            return null;
        }

        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];
        int len;

        // Read bytes from the InputStream and write to the ByteArrayOutputStream
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }

        // Close streams
        try {
            byteBuffer.close();
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return byteBuffer.toByteArray();
    }
}
