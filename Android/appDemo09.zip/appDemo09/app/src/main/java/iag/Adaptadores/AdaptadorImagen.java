package iag.Adaptadores;
import android.content.Context;
import android.view.LayoutInflater;
import android.widget.ArrayAdapter;
import java.util.ArrayList;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import iag.Entidades.beImagen;
import iag.Modulos.Imagen;
import iag.appdemo09.R;

public class AdaptadorImagen extends ArrayAdapter {
    public AdaptadorImagen(Context context, ArrayList<beImagen> data) {
        super(context, 0, data);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        beImagen obeImagen = (beImagen)getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.cara, parent, false);
        }
        if(obeImagen!=null){
            ImageView imgCara = convertView.findViewById(R.id.imgCara);
            Imagen.mostrarDesdeBytes(obeImagen.Imagen, imgCara);
        }
        return convertView;
    }
}
