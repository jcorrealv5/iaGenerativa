package iag.appdemo09;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Arrays;
import iag.Adaptadores.AdaptadorImagen;
import iag.Interfaces.CallbackAsync;
import iag.Modulos.ClienteBytesHttp;
import iag.Entidades.beImagen;
import iag.Modulos.Imagen;

public class MainActivity extends AppCompatActivity {
    TextView lblProgreso;
    String[] archivos;
    int nArchivos = 0;
    int cArchivos = 0;
    ListView lvwCaras;
    ArrayList<beImagen> listaCaras;
    String cara="";
    Spinner cboPelo;
    ImageView imgCara;
    String color;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lblProgreso = findViewById(R.id.lblProgreso);
        lvwCaras = findViewById(R.id.lvwCaras);
        cboPelo = findViewById(R.id.cboPelo);
        imgCara = findViewById(R.id.imgCara);
        Button btnCambiarPelo=findViewById(R.id.btnCambiarPelo);
        btnCambiarPelo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                servicioCambiarPelo();
            }
        });

        llenarComboPelo();

        cboPelo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                color = String.valueOf(i);
                imgCara.setImageDrawable(null);
                servicioListarArchivos();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        lvwCaras.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                beImagen obeImagen = (beImagen)adapterView.getItemAtPosition(i);
                cara=obeImagen.Id;
                imgCara.setImageDrawable(null);
                lblProgreso.setText("Cara: " + cara);
            }
        });
    }

    protected void llenarComboPelo(){
        ArrayList<String> listaNombres=new ArrayList<>();
        listaNombres.add("Rubio");
        listaNombres.add("Negro");
        ArrayAdapter<String> adaptador=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,listaNombres);
        cboPelo.setAdapter(adaptador);
    }

    protected void servicioListarArchivos(){
        String urlServicio = getResources().getString(R.string.urlServicioWeb);
        String urlMetodo = urlServicio + "ListarArchivos?color=" + color;
        ClienteBytesHttp.get(urlMetodo, new CallbackAsync() {
            @Override
            public void MostrarRespuestaBytesAsync(byte[] rpta) {
                if (rpta != null && rpta.length > 0) {
                    String rptaTexto = new String(rpta);
                    archivos =  rptaTexto.split(",");
                    nArchivos = archivos.length;
                    cArchivos = 0;
                    lblProgreso.setText(String.valueOf(nArchivos));
                    listaCaras=new ArrayList<beImagen>();
                    servicioObtenerImagen();
                }
            }
        });
    }

    protected void servicioObtenerImagen(){
        String urlServicio = getResources().getString(R.string.urlServicioWeb);
        String urlMetodo = urlServicio + "ObtenerImagen?color=" + color;
        urlMetodo += "&nombre=" + archivos[cArchivos];
        ClienteBytesHttp.get(urlMetodo, new CallbackAsync() {
            @Override
            public void MostrarRespuestaBytesAsync(byte[] rpta) {
                if (rpta != null && rpta.length > 0) {
                    beImagen obeImagen=new beImagen();
                    obeImagen.Id = archivos[cArchivos];
                    obeImagen.Imagen = rpta;
                    listaCaras.add(obeImagen);
                    AdaptadorImagen adaptador = new AdaptadorImagen(getApplicationContext(), listaCaras);
                    lvwCaras.setAdapter(adaptador);
                    cArchivos++;
                    lblProgreso.setText(String.valueOf(cArchivos) + " de " + String.valueOf(nArchivos));
                    if(cArchivos<nArchivos) servicioObtenerImagen();
                }
            }
        });
    }

    private void servicioCambiarPelo(){
        String urlServicio = getResources().getString(R.string.urlServicioWeb);
        String urlMetodo = urlServicio + "CambiarPelo?color=" + color;
        urlMetodo += "&nombre=" + cara;
        ClienteBytesHttp.get(urlMetodo, new CallbackAsync() {
            @Override
            public void MostrarRespuestaBytesAsync(byte[] rpta) {
                if(rpta!=null && rpta.length>0){
                    Imagen.mostrarDesdeBytes(rpta, imgCara);
                }
            }
        });
    }
}