package iag.Entidades;

public class beImagen {
    public String Id;
    public byte[] Imagen;
}
