package iag.appdemo08;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Arrays;
import iag.Adaptadores.AdaptadorImagen;
import iag.Interfaces.CallbackAsync;
import iag.Modulos.ClienteBytesHttp;
import iag.Entidades.beImagen;
import iag.Modulos.Imagen;

public class MainActivity extends AppCompatActivity {
    TextView lblProgreso;
    String[] archivos;
    int nArchivos = 0;
    int cArchivos = 0;
    ListView lvwCaras;
    ArrayList<beImagen> listaCaras;
    int cClicks = 0;
    String cara1="";
    String cara2="";
    EditText txtNumero;
    ImageView imgCara;
    ArrayList<byte[]> listaImagenes;
    int c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lblProgreso = findViewById(R.id.lblProgreso);
        lvwCaras = findViewById(R.id.lvwCaras);
        txtNumero = findViewById(R.id.txtNumero);
        imgCara = findViewById(R.id.imgCara);
        Button btnGenerar=findViewById(R.id.btnGenerar);
        btnGenerar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                servicioGenerarCaras();
            }
        });

        servicioListarArchivos();

        lvwCaras.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                cClicks++;
                beImagen obeImagen = (beImagen)adapterView.getItemAtPosition(i);
                if(cClicks==1){
                    cara1=obeImagen.Id;
                }
                if(cClicks==2){
                    cara2=obeImagen.Id;
                    cClicks=0;
                }
                lblProgreso.setText("Cara 1: " + cara1 + " - Cara 2: " + cara2);
            }
        });
    }

    protected void servicioListarArchivos(){
        String urlServicio = getResources().getString(R.string.urlServicioWeb);
        String urlMetodo = urlServicio + "ListarArchivos";
        ClienteBytesHttp.get(urlMetodo, new CallbackAsync() {
            @Override
            public void MostrarRespuestaBytesAsync(byte[] rpta) {
                if (rpta != null && rpta.length > 0) {
                    String rptaTexto = new String(rpta);
                    archivos =  rptaTexto.split(",");
                    nArchivos = archivos.length;
                    cArchivos = 0;
                    lblProgreso.setText(String.valueOf(nArchivos));
                    listaCaras=new ArrayList<beImagen>();
                    servicioObtenerImagen();
                }
            }
        });
    }

    protected void servicioObtenerImagen(){
        String urlServicio = getResources().getString(R.string.urlServicioWeb);
        String urlMetodo = urlServicio + "ObtenerImagen?nombre=" + archivos[cArchivos];
        ClienteBytesHttp.get(urlMetodo, new CallbackAsync() {
            @Override
            public void MostrarRespuestaBytesAsync(byte[] rpta) {
                if (rpta != null && rpta.length > 0) {
                    beImagen obeImagen=new beImagen();
                    obeImagen.Id = archivos[cArchivos];
                    obeImagen.Imagen = rpta;
                    listaCaras.add(obeImagen);
                    AdaptadorImagen adaptador = new AdaptadorImagen(getApplicationContext(), listaCaras);
                    lvwCaras.setAdapter(adaptador);
                    cArchivos++;
                    lblProgreso.setText(String.valueOf(cArchivos) + " de " + String.valueOf(nArchivos));
                    if(cArchivos<nArchivos) servicioObtenerImagen();
                }
            }
        });
    }

    private void servicioGenerarCaras(){
        String numero = txtNumero.getText().toString();
        int nroVeces = Integer.parseInt(numero);
        c=0;
        String urlServicio = getResources().getString(R.string.urlServicioWeb);
        String urlMetodo = urlServicio + "CrearTransicion?cara1=" + cara1;
        urlMetodo += "&cara2=" + cara2 + "&veces=" + numero;
        ClienteBytesHttp.get(urlMetodo, new CallbackAsync() {
            @Override
            public void MostrarRespuestaBytesAsync(byte[] rpta) {
                if(rpta!=null && rpta.length>0){
                    int n1 = rpta[0] & 0xFF;
                    int n2 = rpta[1] & 0xFF;
                    int nTexto = n1 * 255 + n2;
                    byte[] rptaTexto = Arrays.copyOfRange(rpta, 2, 2 + nTexto);
                    String strSizes = new String(rptaTexto);
                    String[] listaSizes = strSizes.split("\\|");
                    listaImagenes = new ArrayList<byte[]>();
                    int x = 2 + nTexto;
                    byte[] buffer;
                    int size;
                    for(int i=0;i<listaSizes.length;i++){
                        size = Integer.parseInt(listaSizes[i]);
                        buffer = Arrays.copyOfRange(rpta, x, x + size);
                        listaImagenes.add(buffer);
                        x += size;
                    }
                    imgCara.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            mostrarImagen();
                            c++;
                            lblProgreso.setText(String.valueOf(c) + " de " + String.valueOf(nroVeces));
                            if(c<nroVeces){
                                imgCara.postDelayed(this, 250);
                            }
                        }
                    }, 250);
                }
            }
        });
    }

    private void mostrarImagen(){
        Imagen.mostrarDesdeBytes(listaImagenes.get(c), imgCara);
    }
}