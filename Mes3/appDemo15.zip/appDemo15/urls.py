from django.urls import path
from . import views
urlpatterns = [
    path('CambioPelo', views.CambioPelo, name='CambioPelo'),
    path('ListarArchivos', views.ListarArchivos, name='ListarArchivos'),
    path('ObtenerImagen', views.ObtenerImagen, name='ObtenerImagen'),
    path('CambiarPelo', views.CambiarPelo, name='CambiarPelo')
]