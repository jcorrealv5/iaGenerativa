var archivos = [];
var nArchivos = 0;
var cArchivos = 0;
var nombre = "";

window.onload = function () {
	var listaColores = ["|Seleccione", "0|Rubio", "1|Negro"];
	crearCombo(listaColores, cboColorPelo);

	cboColorPelo.onchange = function () {
		cargarCaras();
    }

	btnCambiarPelo.onclick = async function () {
		if (cboColorPelo.value != "") {
			if (nombre != "") {
				var color = cboColorPelo.value;
				var url = "CambiarPelo?color=" + color + "&nombre=" + nombre;
				var rptaHttp = await fetch(url, { method: "GET" });
				if (rptaHttp.ok) {
					var blob = await rptaHttp.blob();
					var nTotal = blob.size;
					if (nTotal > 0) {
						var blobImagen = new Blob([blob], { "type": "image/jpg" });
						imgPeloCambiado.src = URL.createObjectURL(blobImagen);
					}
				}
			}
			else alert("Selecciona una imagen a cambiar el Pelo");
		}
		else alert("Selecciona el Color de Pelo");
	}

	btnNuevo.onclick = function () {
		nombre = "";
		cboColorPelo.value = "";
		divCaras.innerHTML = "";
		imgPeloCambiado.src = "";
    }
}

async function cargarCaras() {
	var color = cboColorPelo.value;
	var rptaHttp = await fetch("ListarArchivos?color=" + color, { method: "GET" });
	if (rptaHttp.ok) {
		divCaras.innerHTML = "";
		var texto = await rptaHttp.text();
		archivos = texto.split(",");
		nArchivos = archivos.length;
		cArchivos = 0;
		cargarArchivoImagen();
	}
}

async function cargarArchivoImagen() {
	var nombre = archivos[cArchivos];
	var color = cboColorPelo.value;
	var url = "ObtenerImagen?color=" + color + "&nombre=" + nombre;
	var rptaHttp = await fetch(url, { method: "GET" });
	if (rptaHttp.ok) {
		var blob = await rptaHttp.blob();
		var nTotal = blob.size;
		if (nTotal > 0) {
			var blobImagen = new Blob([blob], { "type": "image/jpg" });
			var img = new Image(256, 256);
			img.src = URL.createObjectURL(blobImagen);
			var div = document.createElement("div");
			div.id = nombre;			
			div.style = "float:left;width:300px;height:300px;padding:22px";
			div.appendChild(img);
			divCaras.appendChild(div);
			cArchivos++;
			if (cArchivos < nArchivos) cargarArchivoImagen();
			else configurarDivs();
		}
	}
}

function iniciarDivs() {
	var divs = divCaras.childNodes;
	var nDivs = divs.length;
	for (var i = 0; i < nDivs; i++) {
		divs[i].style.backgroundColor = "";
	}
}

function configurarDivs() {
	var divs = divCaras.childNodes;
	var nDivs = divs.length;
	for (var i = 0; i < nDivs; i++) {
		divs[i].onclick = function () {			
			iniciarDivs();
			this.style.backgroundColor = "yellow";
			nombre = this.id;
        }
    }
}

function crearCombo(lista, cbo, primerItem) {
	var primerItem = (primerItem == null ? "" : primerItem);
	var html = "";
	var nRegistros = lista.length;
	var campos = [];
	if (primerItem != "") {
		html += "<option value=''>";
		html += primerItem;
		html += "</option>";
	}
	for (var i = 0; i < nRegistros; i++) {
		campos = lista[i].split("|");
		html += "<option value='";
		html += campos[0];
		html += "'>";
		html += campos[1];
		html += "</option>";
	}
	cbo.innerHTML = html;
}