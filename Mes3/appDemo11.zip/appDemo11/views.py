from django.http import HttpResponse
from django.shortcuts import render
import torch, torchvision, cv2
import torchvision.transforms as T
import numpy as np
import os
from io import BytesIO
from PIL import Image
from modVAE import Encoder, Decoder, VAE

def TransicionCaras(request):
    return render(request, "appDemo11/TransicionCaras.html")

def ListarArchivos(request):
    ruta = "C:/Data/Python/2026_01_IAG/Demos/datasets/TestLentes"
    archivos = os.listdir(ruta)
    rpta = ",".join(archivos)
    return HttpResponse(rpta)

def ObtenerImagen(request):
    rpta = None
    nombre = request.GET.get("nombre")
    ruta = "C:/Data/Python/2026_01_IAG/Demos/datasets/TestLentes"
    archivo = os.path.join(ruta, nombre)
    if(os.path.isfile(archivo)):
        with open(archivo,"rb") as file:
            rpta = file.read()
    return HttpResponse(rpta)

def fileToTensor(archivo):
    transform = T.Compose([T.ToTensor(),T.Resize(256)])
    img = Image.open(archivo)
    img_tensor = transform(img)
    return img_tensor

def CrearTransicion(request):
    rpta = None
    cara1 = request.GET.get("cara1")
    cara2 = request.GET.get("cara2")
    veces = int(request.GET.get("veces"))
    ruta = "C:/Data/Python/2026_01_IAG/Demos/datasets/TestLentes"
    archivo1 = os.path.join(ruta, cara1)
    archivo2 = os.path.join(ruta, cara2)
    tensorCara1 = fileToTensor(archivo1)
    tensorCara2 = fileToTensor(archivo2)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    modelo=VAE().to(device)
    modelo.eval()
    modelo.load_state_dict(torch.load('C:/Data/Python/2026_01_IAG/Demos/preentrenados/VAE/Lentes/VAE_Lentes_992_469.14268473835733.pt', map_location=device))
    cara1 = tensorCara1.unsqueeze(0)
    cara2 = tensorCara2.unsqueeze(0)
    _,_,code1=modelo.encoder(cara1)
    _,_,code2=modelo.encoder(cara2)
    c = 0
    imagenes = []
    texto = ""
    for w in np.linspace(0,1,veces):
        c=c+1
        z=w*code2+(1-w)*code1
        imgReconstruida=modelo.decoder(z)
        img_tensor = imgReconstruida.reshape((3, 256, 256))
        img_array = np.transpose(img_tensor.detach().cpu().numpy(), (1, 2, 0))
        #img_rgb = cv2.cvtColor(img_array, cv2.COLOR_BGR2RGB)              
        img_array = (img_array * 255).clip(0, 255).astype(np.uint8)
        imgBytes = convertirNumPyToBytes(img_array)
        imagenes.append(imgBytes)
        texto += str(len(imgBytes))
        if(c<veces):
            texto += "|"
    print("texto: ", texto)
    nTexto = len(texto)
    bytesRpta = []
    byte1 = int(nTexto / 255)
    byte2 = int(nTexto % 255)
    bytesTexto = texto.encode(encoding="utf-8")
    bytesRpta.append(byte1)
    bytesRpta.append(byte2)
    bytesRpta.extend(bytesTexto)
    for i in range(len(imagenes)):
        bytesRpta.extend(imagenes[i])
    rpta = bytes(bytesRpta)
    return HttpResponse(rpta)

def convertirNumPyToBytes(imagen):
    imagenPIL = Image.fromarray(imagen)
    imagenBuffer = BytesIO()
    imagenPIL.save(imagenBuffer, format="PNG")
    rpta = imagenBuffer.getvalue()
    return rpta