var blobs = [];
var archivos = [];
var nArchivos = 0;
var cArchivos = 0;
var cClicks = 0;
var divAnterior = null;
var idAnima = "";
var nBlob = 0;
var cBlob = 0;

window.onload = function () {
	cargarCaras();

	btnCrearTransicion.onclick = function () {
		cBlob = 0;
		blobs = [];
		if (spnCara1.innerText != "" && spnCara2.innerText != "" && txtVeces.value!="") {
			crearTransicion();
		}
		else alert("Selecciona 2 Caras para realizar la Transicion");
	}

	btnNuevo.onclick = function () {
		spnCara1.innerText = "";
		spnCara2.innerText = "";
		txtVeces.value = "10";
		iniciarDivs();
		cClicks = 0;
		divAnterior = null;
    }
}

async function cargarCaras() {
	var rptaHttp = await fetch("ListarArchivos", { method: "GET" });
	if (rptaHttp.ok) {
		var texto = await rptaHttp.text();
		archivos = texto.split(",");
		nArchivos = archivos.length;
		cArchivos = 0;
		cargarArchivoImagen();
	}
}

async function cargarArchivoImagen() {
	var nombre = archivos[cArchivos];
	var url = "ObtenerImagen?nombre=" + nombre;
	var rptaHttp = await fetch(url, { method: "GET" });
	if (rptaHttp.ok) {
		var blob = await rptaHttp.blob();
		var nTotal = blob.size;
		if (nTotal > 0) {
			var blobImagen = new Blob([blob], { "type": "image/jpg" });
			var img = new Image(256, 256);
			img.src = URL.createObjectURL(blobImagen);
			var div = document.createElement("div");
			div.id = nombre;			
			div.style = "float:left;width:300px;height:300px;padding:22px";
			div.appendChild(img);
			divCaras.appendChild(div);
			cArchivos++;
			if (cArchivos < nArchivos) cargarArchivoImagen();
			else configurarDivs();
		}
	}
}

function iniciarDivs() {
	var divs = divCaras.childNodes;
	var nDivs = divs.length;
	for (var i = 0; i < nDivs; i++) {
		divs[i].style.backgroundColor = "";
	}
}

function configurarDivs() {
	var divs = divCaras.childNodes;
	var nDivs = divs.length;
	cClicks = 0;
	for (var i = 0; i < nDivs; i++) {
		divs[i].onclick = function () {			
			iniciarDivs();
			if (divAnterior != null) divAnterior.style.backgroundColor = "yellow";
			divAnterior = this;
			this.style.backgroundColor = "yellow";
			if (cClicks == 0) spnCara1.innerText = this.id;
			if (cClicks == 1) spnCara2.innerText = this.id;
			cClicks++;
			if (cClicks == 2) cClicks = 0;
        }
    }
}

async function crearTransicion() {
	var cara1 = spnCara1.innerText;
	var cara2 = spnCara2.innerText;
	var veces = txtVeces.value;
	var url = "CrearTransicion?cara1=" + cara1 + "&cara2=" + cara2 + "&veces=" + veces;
	var rptaHttp = await fetch(url, { method: "GET" });
	if (rptaHttp.ok) {
		var blob = await rptaHttp.blob();
		var nTotal = blob.size;
		if (nTotal > 0) {
			//Obtener el Byte 1
			var byte1 = blob.slice(0, 1);
			var buffer1 = await byte1.arrayBuffer();
			var array1 = new Uint8Array(buffer1);
			var n1 = array1[0];
			//Obtener el Byte 2
			var byte2 = blob.slice(1, 2);
			var buffer2 = await byte2.arrayBuffer();
			var array2 = new Uint8Array(buffer2);
			var n2 = array2[0];
			//Obtener el Tamanio del Texto
			var nTexto = (n1 * 255) + n2
			//Obtener el Texto
			var bytesTexto = blob.slice(2, 2 + nTexto);
			var bufferTexto = await bytesTexto.arrayBuffer();
			var arrayTexto = new Uint8Array(bufferTexto);
			var texto = "";
			for (var i = 0; i < nTexto; i++) {
				texto += String.fromCharCode(arrayTexto[i]);
			}
			var lista = texto.split("|");
			var nRegistros = lista.length;
			var x = 2 + nTexto;
			var size, bytesImagen;
			nBlob = nRegistros;
			cBlob = 0;
			for (var i = 0; i < nRegistros; i++) {
				size = +lista[i];
				bytesImagen = blob.slice(x, x + size);
				var blobImagen = new Blob([bytesImagen], { "type": "image/jpg" });
				blobs.push(blobImagen);
				x += size;
			}
			idAnima = setInterval(mostrarCara, 100);
		}
    }
}

function mostrarCara() {
	spnProgreso.innerText = (cBlob + 1) + " de " + nBlob;
	imgCara.src = URL.createObjectURL(blobs[cBlob]);
	cBlob++;
	if (cBlob == nBlob) clearInterval(idAnima);
}