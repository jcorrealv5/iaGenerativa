from django.urls import path
from . import views
urlpatterns = [
    path('TransicionCaras', views.TransicionCaras, name='TransicionCaras'),
    path('ListarArchivos', views.ListarArchivos, name='ListarArchivos'),
    path('ObtenerImagen', views.ObtenerImagen, name='ObtenerImagen'),
    path('CrearTransicion', views.CrearTransicion, name='CrearTransicion')
]