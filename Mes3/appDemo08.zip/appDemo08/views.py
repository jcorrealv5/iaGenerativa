from django.http import HttpResponse
from django.shortcuts import render
import torch, torchvision, cv2
import torchvision.transforms as T
import numpy as np
from io import BytesIO
from PIL import Image

def GenerarCaraAlumno(request):
    return render(request, "appDemo08/GenerarCaraAlumno.html")

def GenerarCaras(request):
    rpta = None
    filas = int(request.GET.get("filas"))
    cols = int(request.GET.get("cols"))
    device = "cuda" if torch.cuda.is_available() else "cpu"
    modelo=torch.jit.load('C:/Data/Python/2026_01_IAG/Demos/preentrenados/VAE/Caras/VAE_Caras_Final_79.35767582484654.pt',map_location=device)
    modelo.eval()
    y = 3.5
    c = 0
    imagenes = []
    texto = ""
    n = filas * cols
    for i in range(filas):
        x = -3.5
        for j in range(cols):
            c=c+1
            z_sample = torch.tensor([[x, y]], dtype=torch.float).to(device)
            x_decoded = modelo.decode(z_sample)
            imgTensor = x_decoded.detach().cpu().reshape(3, 100, 100)
            img_array = np.transpose(imgTensor.numpy(),(1,2,0)) 
            img_rgb = cv2.cvtColor(img_array, cv2.COLOR_BGR2RGB)
            img_final = (img_rgb * 255).clip(0, 255).astype(np.uint8)
            imgBytes = convertirNumPyToBytes(img_final)
            imagenes.append(imgBytes)
            texto += str(len(imgBytes))
            if(i<n-1):
                texto += "|"
            x += 7/cols
        y -= 7/filas
        nTexto = len(texto)
    bytesRpta = []
    byte1 = int(nTexto / 255)
    byte2 = int(nTexto % 255)
    bytesTexto = texto.encode(encoding="utf-8")
    bytesRpta.append(byte1)
    bytesRpta.append(byte2)
    bytesRpta.extend(bytesTexto)
    for i in range(len(imagenes)):
        bytesRpta.extend(imagenes[i])
    rpta = bytes(bytesRpta)
    return HttpResponse(rpta)

def convertirNumPyToBytes(imagen):
    imagenPIL = Image.fromarray(imagen)
    imagenBuffer = BytesIO()
    imagenPIL.save(imagenBuffer, format="PNG")
    rpta = imagenBuffer.getvalue()
    return rpta