window.onload = function () {
    btnGenerar.onclick = function () {
        generarCaras();
	}

	btnNuevo.onclick = function () {
		divCaras.innerHTML = "";
		txtNumFilas.value = "5";
		txtNumCols.value = "5";
    }
}

async function generarCaras() {
	var filas = txtNumFilas.value;
	var cols = txtNumCols.value;
	var rptaHttp = await fetch("GenerarCaras?filas=" + filas + "&cols=" + cols, { method: "GET" });
	if (rptaHttp.ok) {
		divCaras.innerHTML = "";
        var blob = await rptaHttp.blob();
		var nTotal = blob.size;
		if (nTotal > 0) {
			//Obtener el Byte 1
			var byte1 = blob.slice(0, 1);
			var buffer1 = await byte1.arrayBuffer();
			var array1 = new Uint8Array(buffer1);
			var n1 = array1[0];
			//Obtener el Byte 2
			var byte2 = blob.slice(1, 2);
			var buffer2 = await byte2.arrayBuffer();
			var array2 = new Uint8Array(buffer2);
			var n2 = array2[0];
			//Obtener el Tamanio del Texto
			var nTexto = (n1 * 255) + n2
			//Obtener el Texto
			var bytesTexto = blob.slice(2, 2 + nTexto);
			var bufferTexto = await bytesTexto.arrayBuffer();
			var arrayTexto = new Uint8Array(bufferTexto);
			var texto = "";
			for (var i = 0; i < nTexto; i++) {
				texto += String.fromCharCode(arrayTexto[i]);
			}
			var lista = texto.split("|");
			var x = 2 + nTexto;
			var size, bytesImagen, img;
			var c = 0;
			var div;
			for (var i = 0; i < filas; i++) {
				div = document.createElement("div");				
				for (var j = 0; j < cols; j++) {
					size = +lista[c];
					bytesImagen = blob.slice(x, x + size);
					var blobImagen = new Blob([bytesImagen], { "type": "image/jpg" });
					var img = new Image(56, 56);
					img.src = URL.createObjectURL(blobImagen);
					div.appendChild(img);
					x += size;
					c++;
				}
				divCaras.appendChild(div);
			}
		}
    }
}