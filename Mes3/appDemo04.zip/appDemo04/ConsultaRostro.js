var nMuestras = 0;
var contador = 0;

window.onload = function () {
    btnGenerar.onclick = function () {
        divProgreso.style.display = "inline";
        nMuestras = +txtMuestras.value;
        contador = 0;
        pbrCara.value = 0;
        pbrCara.max = nMuestras;
        generarRostro();
    }

    btnNuevo.onclick = function () {
        divProgreso.style.display = "none";
        spnProgresoCara.innerText = "";
        pbrCara.value = 0;
        divRostro.innerHTML = "";
    }
}

async function generarRostro() {
    var rptaHttp = await fetch("GenerarRostro", { method: "GET" });
    if (rptaHttp.ok) {
        var rptaBlob = await rptaHttp.blob();
        if (rptaBlob.size > 0) {
            var imgRostro = new Image(256, 256);
            imgRostro.src = URL.createObjectURL(rptaBlob);
            //divRostro.appendChild(imgRostro);
            divRostro.insertAdjacentHTML("afterbegin", imgRostro.outerHTML);
            contador += 1;
            pbrCara.value++;
            spnProgresoCara.innerText = contador + " de " + nMuestras;
            if (contador < nMuestras) generarRostro();
        }
    }
}