var idAnimacion;

window.onload = function () {
    btnGenerar.onclick = function () {
        idAnimacion = null;
        generarRostro();
    }
    btnGenerarAnimado.onclick = function () {
        idAnimacion = requestAnimationFrame(generarRostro);
    }
}

async function generarRostro() {
    var rptaHttp = await fetch("GenerarRostro", { method: "GET" });
    if (rptaHttp.ok) {
        var rptaBlob = await rptaHttp.blob();
        if (rptaBlob.size > 0) {
            imgRostro.src = URL.createObjectURL(rptaBlob);
            if (idAnimacion != null) idAnimacion = requestAnimationFrame(generarRostro);
        }
    }
}