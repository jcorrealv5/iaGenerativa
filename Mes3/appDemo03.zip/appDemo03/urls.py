from django.urls import path
from . import views
urlpatterns = [
    path('ConsultaRostro', views.ConsultaRostro, name='ConsultaRostro'),
    path('GenerarRostro', views.GenerarRostro, name='GenerarRostro')
]