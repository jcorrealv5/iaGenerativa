from django.urls import path
from . import views
urlpatterns = [
    path('ConsultaCaras', views.ConsultaCaras, name='ConsultaCaras'),
    path('GenerarCara', views.GenerarCara, name='GenerarCara')
]