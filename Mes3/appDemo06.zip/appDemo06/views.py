from django.http import HttpResponse
from django.shortcuts import render
import torch, cv2
import numpy as np
from io import BytesIO
from PIL import Image
from diffusers import DDPMPipeline, DDIMScheduler

def ConsultaCaras(request):
    return render(request, "appDemo06/ConsultaCaras.html")

def GenerarCara(request):
    rpta = None
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    scheduler = DDIMScheduler.from_pretrained("google/ddpm-celebahq-256")
    scheduler.set_timesteps(num_inference_steps=40)
    pipeline = DDPMPipeline.from_pretrained("google/ddpm-celebahq-256")
    pipeline.to(device)
    pipeline.scheduler = scheduler
    imagenesGeneradas = pipeline(num_inference_steps=40).images
    img = np.array(imagenesGeneradas[0])
    imgBytes = convertirNumPyToBytes(img)
    return HttpResponse(imgBytes)

def convertirNumPyToBytes(imagen):
    imagenPIL = Image.fromarray(imagen)
    imagenBuffer = BytesIO()
    imagenPIL.save(imagenBuffer, format="PNG")
    rpta = imagenBuffer.getvalue()
    return rpta