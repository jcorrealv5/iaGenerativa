var nMuestras = 0;
var cMuestras = 0;

window.onload = function () {
	btnGenerar.onclick = function () {
		btnGenerar.disabled = true;
		cMuestras = 0;
		nMuestras = +txtMuestras.value;
		spnProgreso.innerText = "";
		divCaras.innerHTML = "";
		generarCaras();
	}

	btnNuevo.onclick = function () {
		spnProgreso.innerText = "";
		divCaras.innerHTML = "";
    }
}

async function generarCaras() {    
	var rptaHttp = await fetch("GenerarCara", { method: "GET" });
	if (rptaHttp.ok) {		
        var blob = await rptaHttp.blob();
		var nTotal = blob.size;
		if (nTotal > 0) {			
			var blobImagen = new Blob([blob], { "type": "image/jpg" });
			var img = new Image(256, 256);
			img.src = URL.createObjectURL(blobImagen);
			divCaras.appendChild(img);
			cMuestras++;
			spnProgreso.innerText = cMuestras + " de " + nMuestras;
			if (cMuestras < nMuestras) generarCaras();
			else {
				btnGenerar.disabled = false;
				alert("Fin de la Generacion");
			}
		}
    }
}