from django.urls import path
from . import views
urlpatterns = [
    path('GeneracionAnimes', views.GeneracionAnimes, name='GeneracionAnimes'),
    path('GenerarAnimes', views.GenerarAnimes, name='GenerarAnimes')
]