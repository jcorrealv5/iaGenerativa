from django.http import HttpResponse
from django.shortcuts import render
import torch, torchvision, cv2
import torchvision.transforms as T
import numpy as np
import os
from io import BytesIO
from PIL import Image
from modVAE import Encoder, Decoder, VAE

def GeneracionAnimes(request):
    return render(request, "appDemo12/GeneracionAnimes.html")

def GenerarAnimes(request):
    rpta = None
    batch_size = int(request.GET.get("cantidad"))
    device="cuda" if torch.cuda.is_available() else "cpu"
    archivo = "C:/Data/Python/2026_01_IAG/Demos/preentrenados/GAN/Animes/GAN_Animes_100_7.748009204864502.pt"
    G=torch.jit.load(archivo, map_location=device)
    G.eval()
    ruido=torch.randn(batch_size,100,1,1).to(device=device)
    imagenesGeneradas=G(ruido).cpu().detach()
    imagenes = []
    texto = ""
    for i in range(batch_size):
        imagenTensor = imagenesGeneradas[i]/2+0.5 #-1,1
        imagenTensor = (imagenTensor.clamp(0, 1) * 255).byte() #0,1 => 0,255
        imagenArray = imagenTensor.permute(1,2,0).cpu().numpy()
        imagenArray = cv2.resize(imagenArray, (128,128))
        imgBytes = convertirNumPyToBytes(imagenArray)
        imagenes.append(imgBytes)
        texto += str(len(imgBytes))
        if(i<batch_size-1):
            texto += "|"
    nTexto = len(texto)
    bytesRpta = []
    byte1 = int(nTexto / 255)
    byte2 = int(nTexto % 255)
    bytesTexto = texto.encode(encoding="utf-8")
    bytesRpta.append(byte1)
    bytesRpta.append(byte2)
    bytesRpta.extend(bytesTexto)
    for i in range(len(imagenes)):
        bytesRpta.extend(imagenes[i])
    rpta = bytes(bytesRpta)
    return HttpResponse(rpta)

def convertirNumPyToBytes(imagen):
    imagenPIL = Image.fromarray(imagen)
    imagenBuffer = BytesIO()
    imagenPIL.save(imagenBuffer, format="PNG")
    rpta = imagenBuffer.getvalue()
    return rpta