window.onload = function () {
	var listaRisa = ["|Seleccione", "0|Sin Risa", "1|Con Risa"];
	crearCombo(listaRisa, cboRisa);

	btnAbrir.onclick = function () {
		fupFoto.click();
	}

	fupFoto.onchange = function (event) {
		var file = this.files[0];
		var reader = new FileReader();
		reader.onloadend = function (event) {
			imgRisaOriginal.src = reader.result;
        }
		reader.readAsDataURL(file);
    }
	
	btnCambiarRisa.onclick = async function () {
		if (cboRisa.value != "") {
			if (fupFoto.value != "") {
				var risa = cboRisa.value;
				var file = fupFoto.files[0];
				var token = document.getElementsByName("csrfmiddlewaretoken")[0].value;
				var frm = new FormData();
				frm.append("csrfmiddlewaretoken", token);
				frm.append("risa", risa);
				frm.append("archivo", file);				
				var rptaHttp = await fetch("CambiarRisa", { method: "POST", body: frm });
				if (rptaHttp.ok) {
					var blob = await rptaHttp.blob();
					var nTotal = blob.size;
					if (nTotal > 0) {
						var blobImagen = new Blob([blob], { "type": "image/jpg" });
						imgRisaCambiada.src = URL.createObjectURL(blobImagen);
					}
				}
			}
			else alert("Selecciona una imagen a cambiar la Risa");
		}
		else alert("Selecciona el Tipo de Risa");
	}

	btnNuevo.onclick = function () {
		cboRisa.value = "";
		imgRisaOriginal.src = "";
		imgRisaCambiada.src = "";
    }
}

function crearCombo(lista, cbo, primerItem) {
	var primerItem = (primerItem == null ? "" : primerItem);
	var html = "";
	var nRegistros = lista.length;
	var campos = [];
	if (primerItem != "") {
		html += "<option value=''>";
		html += primerItem;
		html += "</option>";
	}
	for (var i = 0; i < nRegistros; i++) {
		campos = lista[i].split("|");
		html += "<option value='";
		html += campos[0];
		html += "'>";
		html += campos[1];
		html += "</option>";
	}
	cbo.innerHTML = html;
}