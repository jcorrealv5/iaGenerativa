from django.http import HttpResponse
from django.shortcuts import render
import torch, cv2
import numpy as np
from io import BytesIO
from PIL import Image

def ConsultaRopa(request):
    return render(request, "appDemo02/ConsultaRopa.html")

def GenerarRopa(request):
    rpta = None
    nMuestras = int(request.GET.get("nMuestras","1"))
    use_gpu = True if torch.cuda.is_available() else False
    model = torch.hub.load('facebookresearch/pytorch_GAN_zoo:hub','DCGAN', pretrained=True, useGPU=use_gpu)
    ruido, _ = model.buildNoiseData(nMuestras)
    with torch.no_grad():
        imagenesGeneradas = model.test(ruido)
    imagenes = []
    texto = ""
    for i in range(nMuestras):
        img = imagenesGeneradas[i]/2+0.5
        img = (img.clamp(0, 1) * 255).byte()
        img = img.permute(1,2,0).cpu().numpy()
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        imgBytes = convertirNumPyToBytes(img)
        imagenes.append(imgBytes)
        texto += str(len(imgBytes))
        if(i<nMuestras-1):
            texto += "|"
    nTexto = len(texto)
    bytesRpta = []
    byte1 = int(nTexto / 255)
    byte2 = int(nTexto % 255)
    bytesTexto = texto.encode(encoding="utf-8")
    bytesRpta.append(byte1)
    bytesRpta.append(byte2)
    bytesRpta.extend(bytesTexto)
    for i in range(len(imagenes)):
        bytesRpta.extend(imagenes[i])
    rpta = bytes(bytesRpta)
    return HttpResponse(rpta)

def convertirNumPyToBytes(imagen):
    imagenPIL = Image.fromarray(imagen)
    imagenBuffer = BytesIO()
    imagenPIL.save(imagenBuffer, format="PNG")
    rpta = imagenBuffer.getvalue()
    return rpta