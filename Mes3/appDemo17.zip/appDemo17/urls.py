from django.urls import path
from . import views
urlpatterns = [
    path('CambioPelo', views.CambioPelo, name='CambioPelo'),
    path('CambiarPelo', views.CambiarPelo, name='CambiarPelo')
]