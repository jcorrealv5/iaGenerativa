window.onload = function () {
	btnGenerarCaras.onclick = function () {
		generarCaras();
	}

	btnNuevo.onclick = function () {
		txtCantidad.value = "20";
		divAlumnos.innerHTML = "";
    }
}

async function generarCaras() {
	divAlumnos.innerHTML = "";
	var cantidad = txtCantidad.value;
	var url = "GenerarCaras?cantidad=" + cantidad;
	var rptaHttp = await fetch(url, { method: "GET" });
	if (rptaHttp.ok) {
		var blob = await rptaHttp.blob();
		var nTotal = blob.size;
		if (nTotal > 0) {
			//Obtener el Byte 1
			var byte1 = blob.slice(0, 1);
			var buffer1 = await byte1.arrayBuffer();
			var array1 = new Uint8Array(buffer1);
			var n1 = array1[0];
			//Obtener el Byte 2
			var byte2 = blob.slice(1, 2);
			var buffer2 = await byte2.arrayBuffer();
			var array2 = new Uint8Array(buffer2);
			var n2 = array2[0];
			//Obtener el Tamanio del Texto
			var nTexto = (n1 * 255) + n2
			//Obtener el Texto
			var bytesTexto = blob.slice(2, 2 + nTexto);
			var bufferTexto = await bytesTexto.arrayBuffer();
			var arrayTexto = new Uint8Array(bufferTexto);
			var texto = "";
			for (var i = 0; i < nTexto; i++) {
				texto += String.fromCharCode(arrayTexto[i]);
			}
			var lista = texto.split("|");
			var nRegistros = lista.length;
			var x = 2 + nTexto;
			var size, bytesImagen;
			nBlob = nRegistros;
			cBlob = 0;
			for (var i = 0; i < nRegistros; i++) {
				size = +lista[i];
				bytesImagen = blob.slice(x, x + size);
				var blobImagen = new Blob([bytesImagen], { "type": "image/jpg" });
				var img = new Image(128, 128);
				img.src = URL.createObjectURL(blobImagen);
				divAlumnos.appendChild(img);
				x += size;
			}
		}
    }
}

function mostrarCara() {
	spnProgreso.innerText = (cBlob + 1) + " de " + nBlob;
	imgCara.src = URL.createObjectURL(blobs[cBlob]);
	cBlob++;
	if (cBlob == nBlob) clearInterval(idAnima);
}