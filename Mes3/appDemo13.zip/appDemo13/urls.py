from django.urls import path
from . import views
urlpatterns = [
    path('GeneracionCaras', views.GeneracionCaras, name='GeneracionCaras'),
    path('GenerarCaras', views.GenerarCaras, name='GenerarCaras')
]