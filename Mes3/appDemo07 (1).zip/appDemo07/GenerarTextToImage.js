window.onload = function () {
	btnGenerar.onclick = function () {
		btnGenerar.disabled = true;
		imgGenerada.src = "";
		generarImagen();
	}

	btnNuevo.onclick = function () {
		imgGenerada.src = "";
    }
}

async function generarImagen() {
	var token = document.getElementsByName("csrfmiddlewaretoken")[0].value;
	var frm = new FormData();
	frm.append("prompt", txtPrompt.value);
	frm.append("prompt_negativo", txtPromptNegativo.value);
	frm.append("csrfmiddlewaretoken", token);
	var rptaHttp = await fetch("GenerarImagen", { method: "POST", body: frm });
	if (rptaHttp.ok) {		
        var blob = await rptaHttp.blob();
		var nTotal = blob.size;
		if (nTotal > 0) {	
			var blobImagen = new Blob([blob], { "type": "image/jpg" });
			imgGenerada.src = URL.createObjectURL(blobImagen);	
			btnGenerar.disabled = false;
		}
    }
}