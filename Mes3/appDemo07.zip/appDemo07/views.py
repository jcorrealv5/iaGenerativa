from django.http import HttpResponse
from django.shortcuts import render
from django.views.decorators.clickjacking import xframe_options_exempt
import torch, cv2
import numpy as np
from io import BytesIO
from PIL import Image
from diffusers import StableDiffusionPipeline

def GenerarTextToImage(request):
    return render(request, "appDemo07/GenerarTextToImage.html")

@xframe_options_exempt
def GenerarImagen(request):
    rpta = None
    prompt = request.POST.get("prompt")
    prompt_negativo = request.POST.get("prompt_negativo")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model_id = "Manojb/stable-diffusion-2-1-base"
    pipeline = StableDiffusionPipeline.from_pretrained(model_id).to(device)
    generator = torch.Generator(device=device).manual_seed(42)
    rpta_pipeline = pipeline(
        prompt=prompt,
        negative_prompt=prompt_negativo,
        height=480, width=640,
        guidance_scale=8,
        num_inference_steps=35,
        generator=generator
    )
    imagenesGeneradas = rpta_pipeline.images
    img = np.array(imagenesGeneradas[0])
    imgBytes = convertirNumPyToBytes(img)
    return HttpResponse(imgBytes)

def convertirNumPyToBytes(imagen):
    imagenPIL = Image.fromarray(imagen)
    imagenBuffer = BytesIO()
    imagenPIL.save(imagenBuffer, format="PNG")
    rpta = imagenBuffer.getvalue()
    return rpta