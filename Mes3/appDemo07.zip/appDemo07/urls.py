from django.urls import path
from . import views
urlpatterns = [
    path('GenerarTextToImage', views.GenerarTextToImage, name='GenerarTextToImage'),
    path('GenerarImagen', views.GenerarImagen, name='GenerarImagen')
]