from django.http import HttpResponse
from django.shortcuts import render
from django.views.decorators.clickjacking import xframe_options_exempt
import torch, torchvision, cv2
import torchvision.transforms as T
import albumentations
from albumentations.pytorch import ToTensorV2
import numpy as np
import os
from io import BytesIO
from PIL import Image
from modGAN import LoadData, Generador

def CambioSexo(request):
    return render(request, "appDemo20/CambioSexo.html")

@xframe_options_exempt
def CambiarSexo(request):
    rpta = None
    sexo = request.POST.get("sexo")
    print("sexo: ", sexo)
    fileOrigen = request.FILES["archivo"]
    fileOrigen.open()
    bytes = fileOrigen.read()
    fileOrigen.close()
    print("size imagen: ", len(bytes))
    imagenSexoActual = convertirBytesToNumPy(bytes)
    batch_size = 1
    transforms = albumentations.Compose(
    [albumentations.Resize(width=256, height=256),
        albumentations.Normalize(mean=[0.5, 0.5, 0.5],
        std=[0.5, 0.5, 0.5],max_pixel_value=255),
        ToTensorV2()],
    additional_targets={"image0": "image"})
    archivoMujer = "C:/Data/Python/2026_01_IAG/Demos/datasets/TestSexo/Femenino/Ana.jpeg"
    archivoHombre = "C:/Data/Python/2026_01_IAG/Demos/datasets/TestSexo/Masculino/Brad_Pitt.jpg"
    device = "cuda" if torch.cuda.is_available() else "cpu"
    gen = Generador(img_channels=3, num_residuals=9).to(device)
    if(sexo=="0"):
        imagenSexoOpuesto = cv2.imread(archivoHombre)        
        gen.load_state_dict(torch.load("C:/Data/Python/2026_01_IAG/Demos/preentrenados/GAN/Sexo/gen_hombre_20.pth",map_location=device))
    else:
        imagenSexoOpuesto = cv2.imread(archivoMujer)
        gen.load_state_dict(torch.load("C:/Data/Python/2026_01_IAG/Demos/preentrenados/GAN/Sexo/gen_mujer_20.pth",map_location=device))
    device = "cuda" if torch.cuda.is_available() else "cpu"
    imagenSexoActual = cv2.cvtColor(imagenSexoActual, cv2.COLOR_BGR2RGB)
    imagenSexoActual = cv2.resize(imagenSexoActual, (256,256))
    if(sexo=="0"):
        augmentations = transforms(image=imagenSexoActual, image0=imagenSexoOpuesto)
    else:
        augmentations = transforms(image=imagenSexoOpuesto, image0=imagenSexoActual)
    imgHombre = augmentations["image0"]
    imgMujer = augmentations["image"]
    dstSexo = [(imgMujer, imgHombre)]
    loaderSexo=torch.utils.data.DataLoader(dstSexo,batch_size=batch_size, shuffle=True, pin_memory=True, drop_last=True)
    for mujer,hombre in loaderSexo:
        if(sexo=="0"):
            fakeSexo=gen(mujer.to(device)).squeeze(0)
        else:
            fakeSexo=gen(hombre.to(device)).squeeze(0)
    imgRpta = fakeSexo/2+0.5
    imgRpta = (imgRpta.clamp(0, 1) * 255).byte()
    imgRpta = imgRpta.permute(1,2,0).cpu().numpy()
    imagen = convertirNumPyToBytes(imgRpta)
    return HttpResponse(imagen)

def convertirNumPyToBytes(imagen):
    imagenPIL = Image.fromarray(imagen)
    imagenBuffer = BytesIO()
    imagenPIL.save(imagenBuffer, format="PNG")
    rpta = imagenBuffer.getvalue()
    return rpta

def convertirBytesToNumPy(buffer):
    imagenPIL = Image.open(BytesIO(buffer))
    imagen = np.array(imagenPIL)
    return imagen