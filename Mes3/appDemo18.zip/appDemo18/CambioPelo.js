var nFiles = 0;
var cFiles = 0;
var archivos = [];
var nombres = [];

window.onload = function () {
	var listaColores = ["|Seleccione", "0|Rubio", "1|Negro"];
	crearCombo(listaColores, cboColorPelo);

	divCaras.ondragover = function (event) {
		event.preventDefault();
	}

	divCaras.ondrop = function (event) {
		event.preventDefault();
		var files = event.dataTransfer.items;
		if (files) {
			var nImagenes = divCaras.childNodes.length;
			var nArrastre = files.length;			
			var file;
			var c = 0;
			for (var i = 0; i < nArrastre; i++) {
				file = event.dataTransfer.items[i].getAsFile();
				nombre = file.name;
				if (nombres.indexOf(nombre)==-1) {
					archivos.push(file);
					nombres.push(nombre);
					c++;
				}
				else alert("Archivo: " + file.name + " ya fue agregado");
			}
			nFiles = nImagenes + c;
			leerImagen();
		}
	}
	
	btnCambiarPelo.onclick = async function () {
		if (cboColorPelo.value != "") {
			cFiles = 0;
			enviarImagen();
		}
		else alert("Selecciona el Color de Pelo");
	}

	btnNuevo.onclick = function () {
		archivos = [];
		nombres = [];
		cFiles = 0;
		cboColorPelo.value = "";		
		divCaras.innerHTML = "";
    }
}

function leerImagen() {
	var file = archivos[cFiles];
	var reader = new FileReader();
	reader.onloadend = function () {
		var img = new Image(256, 256);
		img.id = file.name;
		img.src = reader.result;
		divCaras.appendChild(img);
		cFiles++;
		if (cFiles < nFiles) leerImagen();
	}
	reader.readAsDataURL(file);
}

async function enviarImagen() {
	var color = cboColorPelo.value;
	var blob = archivos[cFiles];
	var token = document.getElementsByName("csrfmiddlewaretoken")[0].value;
	var frm = new FormData();
	frm.append("csrfmiddlewaretoken", token);
	frm.append("color", color);
	frm.append("blob", blob);
	var rptaHttp = await fetch("CambiarPelo", { method: "POST", body: frm });
	if (rptaHttp.ok) {
		var blob = await rptaHttp.blob();
		var nTotal = blob.size;
		if (nTotal > 0) {
			var blobImagen = new Blob([blob], { "type": "image/jpg" });
			var imgPeloCambiado = document.getElementById(nombres[cFiles]);
			if (imgPeloCambiado!=null) imgPeloCambiado.src = URL.createObjectURL(blobImagen);
			cFiles++;
			if (cFiles < nFiles) enviarImagen();
			else alert("Se cambio: " + nFiles + " Pelos")
		}
	}
}

function crearCombo(lista, cbo, primerItem) {
	var primerItem = (primerItem == null ? "" : primerItem);
	var html = "";
	var nRegistros = lista.length;
	var campos = [];
	if (primerItem != "") {
		html += "<option value=''>";
		html += primerItem;
		html += "</option>";
	}
	for (var i = 0; i < nRegistros; i++) {
		campos = lista[i].split("|");
		html += "<option value='";
		html += campos[0];
		html += "'>";
		html += campos[1];
		html += "</option>";
	}
	cbo.innerHTML = html;
}

function convertBase64ToBlob(imagenBase64) {
	var blob = null;
	var bytesCaracteres = atob(imagenBase64);
	var buffer = new Array(bytesCaracteres.length);
	for (let i = 0; i < bytesCaracteres.length; i++) {
		buffer[i] = bytesCaracteres.charCodeAt(i);
	}
	var byteArray = new Uint8Array(buffer);
	blob = new Blob([byteArray], { type: "image/jpeg" });
	return blob;
}