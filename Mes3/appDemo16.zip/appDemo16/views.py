from django.http import HttpResponse
from django.shortcuts import render
from django.views.decorators.clickjacking import xframe_options_exempt
import torch, torchvision, cv2
import torchvision.transforms as T
import albumentations
from albumentations.pytorch import ToTensorV2
import numpy as np
import os
from io import BytesIO
from PIL import Image
from modGAN import LoadData, Generador

def CambioPelo(request):
    return render(request, "appDemo16/CambioPelo.html")

@xframe_options_exempt
def CambiarPelo(request):
    rpta = None
    color = request.POST.get("color")
    fileOrigen = request.FILES["archivo"]
    fileOrigen.open()
    bytes = fileOrigen.read()
    fileOrigen.close()
    imagenPeloActual = convertirBytesToNumPy(bytes)
    batch_size = 1
    transforms = albumentations.Compose(
    [albumentations.Resize(width=256, height=256),
        albumentations.Normalize(mean=[0.5, 0.5, 0.5],
        std=[0.5, 0.5, 0.5],max_pixel_value=255),
        ToTensorV2()],
    additional_targets={"image0": "image"})
    archivoPeloRubio = "C:/Data/Python/2026_01_IAG/Demos/datasets/TestPelo/Blond/Ana.jpeg"
    archivoPeloNegro = "C:/Data/Python/2026_01_IAG/Demos/datasets/TestPelo/Black/A0.png"
    device = "cuda" if torch.cuda.is_available() else "cpu"
    gen = Generador(img_channels=3, num_residuals=9).to(device)
    if(color=="0"):
        imagenPeloOpuesto = cv2.imread(archivoPeloNegro)        
        gen.load_state_dict(torch.load("C:/Data/Python/2026_01_IAG/Demos/preentrenados/GAN/Pelos/gen_black.pth",map_location=device))
    else:
        imagenPeloOpuesto = cv2.imread(archivoPeloRubio)
        gen.load_state_dict(torch.load("C:/Data/Python/2026_01_IAG/Demos/preentrenados/GAN/Pelos/gen_blond.pth",map_location=device))
    device = "cuda" if torch.cuda.is_available() else "cpu"

    imagenPeloActual = cv2.cvtColor(imagenPeloActual, cv2.COLOR_BGR2RGB)
    imagenPeloActual = cv2.resize(imagenPeloActual, (256,256))
    augmentations = transforms(image=imagenPeloOpuesto, image0=imagenPeloActual)
    imgNegro = augmentations["image0"]
    imgRubio = augmentations["image"]
    dstPelo = [(imgNegro, imgRubio)]
    loaderPelo=torch.utils.data.DataLoader(dstPelo,batch_size=batch_size, shuffle=True, pin_memory=True, drop_last=True)
    for black,blond in loaderPelo:
        fakePelo=gen(black.to(device)).squeeze(0)
    imgRpta = fakePelo/2+0.5
    imgRpta = (imgRpta.clamp(0, 1) * 255).byte()
    imgRpta = imgRpta.permute(1,2,0).cpu().numpy()
    imagen = convertirNumPyToBytes(imgRpta)
    return HttpResponse(imagen)

def convertirNumPyToBytes(imagen):
    imagenPIL = Image.fromarray(imagen)
    imagenBuffer = BytesIO()
    imagenPIL.save(imagenBuffer, format="PNG")
    rpta = imagenBuffer.getvalue()
    return rpta

def convertirBytesToNumPy(buffer):
    imagenPIL = Image.open(BytesIO(buffer))
    imagen = np.array(imagenPIL)
    return imagen