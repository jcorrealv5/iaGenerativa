from django.urls import path
from . import views
urlpatterns = [
    path('CambioSexo', views.CambioSexo, name='CambioSexo'),
    path('CambiarSexo', views.CambiarSexo, name='CambiarSexo')
]