window.onload = function () {
	var listaSexo = ["|Seleccione", "0|Femenino", "1|Masculino"];
	crearCombo(listaSexo, cboSexo);

	btnAbrir.onclick = function () {
		fupFoto.click();
	}

	fupFoto.onchange = function (event) {
		var file = this.files[0];
		var reader = new FileReader();
		reader.onloadend = function (event) {
			imgSexoOriginal.src = reader.result;
        }
		reader.readAsDataURL(file);
    }
	
	btnCambiarSexo.onclick = async function () {
		if (cboSexo.value != "") {
			if (fupFoto.value != "") {
				var sexo = cboSexo.value;
				var file = fupFoto.files[0];
				var token = document.getElementsByName("csrfmiddlewaretoken")[0].value;
				var frm = new FormData();
				frm.append("csrfmiddlewaretoken", token);
				frm.append("sexo", sexo);
				frm.append("archivo", file);				
				var rptaHttp = await fetch("CambiarSexo", { method: "POST", body: frm });
				if (rptaHttp.ok) {
					var blob = await rptaHttp.blob();
					var nTotal = blob.size;
					if (nTotal > 0) {
						var blobImagen = new Blob([blob], { "type": "image/jpg" });
						imgSexoCambiado.src = URL.createObjectURL(blobImagen);
					}
				}
			}
			else alert("Selecciona una imagen a cambiar el Sexo");
		}
		else alert("Selecciona el Sexo");
	}

	btnNuevo.onclick = function () {
		cboSexo.value = "";
		imgSexoOriginal.src = "";
		imgSexoCambiado.src = "";
    }
}

function crearCombo(lista, cbo, primerItem) {
	var primerItem = (primerItem == null ? "" : primerItem);
	var html = "";
	var nRegistros = lista.length;
	var campos = [];
	if (primerItem != "") {
		html += "<option value=''>";
		html += primerItem;
		html += "</option>";
	}
	for (var i = 0; i < nRegistros; i++) {
		campos = lista[i].split("|");
		html += "<option value='";
		html += campos[0];
		html += "'>";
		html += campos[1];
		html += "</option>";
	}
	cbo.innerHTML = html;
}